<?php
declare(strict_types=1);
// Keep sessions inside this application rather than relying on a shared WAMP temp directory.
$sessionDir = __DIR__ . '/data/sessions';
if (!is_dir($sessionDir)) mkdir($sessionDir, 0755, true);
session_save_path($sessionDir);
session_start();

const ROOT = __DIR__;
const DATA = ROOT . '/data';
const UPLOADS = ROOT . '/uploads';
foreach ([DATA, UPLOADS] as $dir) if (!is_dir($dir)) mkdir($dir, 0755, true);

function db(): PDO {
  static $db; if ($db) return $db;
  $db = new PDO('sqlite:' . DATA . '/universe.sqlite');
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $db->exec('PRAGMA foreign_keys = ON');
  return $db;
}
function setup(): void {
  $db = db();
  $db->exec("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, slug TEXT NOT NULL UNIQUE, position INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS media (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL CHECK(type IN ('image','video')), filename TEXT NOT NULL, original_name TEXT, title TEXT, caption TEXT, category_id INTEGER, memory_date TEXT, favorite INTEGER DEFAULT 0, featured INTEGER DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL);
    CREATE TABLE IF NOT EXISTS chapters (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, period TEXT, body TEXT, category TEXT, cover_media_id INTEGER, position INTEGER DEFAULT 0, published INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS envelopes (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, style TEXT DEFAULT 'rose', position INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS questions (id INTEGER PRIMARY KEY AUTOINCREMENT, prompt TEXT NOT NULL, options_json TEXT NOT NULL, correct_index INTEGER DEFAULT 0, position INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS future_ideas (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, note TEXT, position INTEGER DEFAULT 0);");
  $count=(int)$db->query('SELECT COUNT(*) FROM settings')->fetchColumn(); if ($count) return;
  $settings=[
   'her_name'=>'Shivani','nickname'=>'Batuk','my_name'=>'Akash','birthday_date'=>'','tagline'=>'Made of little moments, countless memories, and one very special person.','hero_heading'=>'Happy Birthday, Shivani (Batuk) 💗','hero_text'=>"Out of all the people life could have introduced me to, I'm genuinely glad it introduced me to you.",'hero_detail'=>'This little world is filled with memories, laughter, adventures, and a few things I wanted to tell you.','hero_media'=>'','intro_one'=>'Some people become a beautiful part of your story without even realizing it.','intro_two'=>'And sometimes, someone deserves a little universe of their own.','intro_three'=>'Shivani… this little universe is for you. 💗','letter'=>"Hey Batuk,\n\nHappy Birthday, Shivani! 💗\n\nI wanted to create something a little different for you this birthday. Something that isn't just a message on a screen, but a small collection of memories, moments, and feelings that mean a lot to me.\n\nIt's honestly amazing to think that we've known each other for around four to five years. And somewhere during the last one and a half years, our friendship became even closer and more special.\n\nWhen I think about the time we've spent together, I remember our café outings, our game-zone adventures, all those photographs, and our recent Garba memories in Surat.\n\nThey might look like ordinary moments to someone else, but they are memories I genuinely treasure.\n\nI'm really grateful that you're part of my life, Shivani. I hope this birthday brings you happiness, peace, confidence, new experiences, and countless reasons to smile.\n\nThank you for being Batuk. Thank you for being my best friend. And thank you for being such a special part of my story.\n\nWith lots of love and care,\n\nAkash 💗",'final_message'=>"Some moments become photographs.\n\nSome photographs become stories.\n\nAnd some people become a very special part of those stories.\n\nThank you for being part of mine, Batuk.\n\nHappy Birthday, Shivani.\n\nWith love and care,\nAkash ✨",'private_mode'=>'0'];
  $stmt=$db->prepare('INSERT INTO settings(key,value) VALUES(?,?)'); foreach($settings as $k=>$v)$stmt->execute([$k,$v]);
  foreach(['Café Diaries','Game Zone Madness','Surat Garba Nights','Random Little Moments','Favorite Memories'] as $i=>$n){$db->prepare('INSERT INTO categories(name,slug,position) VALUES(?,?,?)')->execute([$n,strtolower(str_replace([' ','é'],['-','e'],$n)),$i]);}
  $chap=[['The Beginning','Around 4–5 years ago','The early pages of a friendship that would become a beautiful part of life.'],['The Little Things','A collection of ordinary moments','The small conversations and shared experiences that quietly turn into memories.'],['Getting Closer','The last 1.5 years','Somewhere along the way, our friendship grew closer and more special.'],['Café Diaries','Our little outings','A place for coffee, photographs, and the kind of days worth keeping.'],['Game Zone Madness','Play, laugh, replay','For the games, the energy, and everything worth replaying.'],['Surat Under the Garba Lights','Navratri in Surat','A little color, a little music, and another memory to keep close.'],['The Story Is Still Being Written','Still unfolding','For all the lovely little moments waiting ahead.']];
  foreach($chap as $i=>$c)$db->prepare('INSERT INTO chapters(title,period,body,position) VALUES(?,?,?,?)')->execute([...$c,$i]);
  $env=[['Open when you need a smile','I hope this tiny note finds a way to brighten your day. You bring a special kind of warmth to the people around you—never forget that.'],['Open when your day isn’t going well','Bad days are only pages, not the whole story. Be gentle with yourself today; you deserve kindness, rest, and a fresh start.'],['Open when you need a reminder of how amazing you are','You are thoughtful, capable, and wonderfully yourself. The world is better for having your particular spark in it.'],['Open when you want to revisit our memories','There are already so many little moments worth keeping—and this universe is here whenever you want to revisit them.'],['Open when you need a little encouragement','Keep going, Batuk. You are more prepared and stronger than you sometimes give yourself credit for.'],['Open on your birthday','Happy Birthday! I hope today makes space for joy, cake, kind people, and every little thing that makes you smile.']];
  foreach($env as $i=>$e)$db->prepare('INSERT INTO envelopes(title,body,position) VALUES(?,?,?)')->execute([...$e,$i]);
  $q=[['Which type of place have we visited together?',['A library','A café','A stadium','An aquarium'],1],['Which city was our recent Garba outing in?',['Vadodara','Surat','Rajkot','Ahmedabad'],1],['Which section holds game-zone videos?',['The Replay Room','The Letter Desk','The Star Map','The Café Table'],0]];
  foreach($q as $i=>$x)$db->prepare('INSERT INTO questions(prompt,options_json,correct_index,position) VALUES(?,?,?,?)')->execute([$x[0],json_encode($x[1]),$x[2],$i]);
  foreach(['More café visits','More game-zone adventures','More random photographs','More Garba nights','More spontaneous outings','More laughs over the smallest things'] as $i=>$x)$db->prepare('INSERT INTO future_ideas(title,note,position) VALUES(?,?,?)')->execute([$x,'A possibility for another lovely chapter.',$i]);
}
setup();
function setting(string $key): string { $s=db()->prepare('SELECT value FROM settings WHERE key=?');$s->execute([$key]);return (string)($s->fetchColumn()??''); }
function settings():array{return db()->query('SELECT key,value FROM settings')->fetchAll(PDO::FETCH_KEY_PAIR);}
function is_admin():bool{return !empty($_SESSION['admin']);}
function csrf():string {if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf'];}
function verify_csrf():void {if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')) throw new RuntimeException('Your session expired. Please try again.');}
function esc(?string $v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function json_out(mixed $x,int $code=200):never{http_response_code($code);header('Content-Type: application/json');echo json_encode($x);exit;}
function media_url(array $m):string{return 'uploads/'.rawurlencode($m['filename']);}
function admin_required():void{if(!is_admin()){header('Location: ?page=login');exit;}}

$page=$_GET['page']??'home';
if($page==='logout'){session_destroy();header('Location: ./');exit;}
if($page==='login' && $_SERVER['REQUEST_METHOD']==='POST'){
  $pass=$_POST['password']??''; $configured=getenv('ADMIN_PASSWORD') ?: '';
  if($configured !== '' && hash_equals($configured,$pass)){session_regenerate_id(true);$_SESSION['admin']=true;csrf();header('Location: ?page=admin');exit;}
  $loginError=$configured === '' ? 'ADMIN_PASSWORD has not been configured on this server.' : 'Incorrect password.';
}
if($page==='api'){
  admin_required(); try {verify_csrf();$action=$_POST['action']??'';$db=db();
   if($action==='upload'){
    $files=$_FILES['files']??null;if(!$files)throw new RuntimeException('Choose at least one file.');$kind=$_POST['type']??'image';$allowed=$kind==='video'?['video/mp4'=>'mp4','video/webm'=>'webm']:['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];$limit=$kind==='video'?150*1024*1024:12*1024*1024;$out=[];
    foreach($files['tmp_name'] as $i=>$tmp){if($files['error'][$i]!==UPLOAD_ERR_OK)throw new RuntimeException('One file could not be uploaded.');if($files['size'][$i]>$limit)throw new RuntimeException('A file exceeds the configured size limit.');$mime=(new finfo(FILEINFO_MIME_TYPE))->file($tmp);if(!isset($allowed[$mime]))throw new RuntimeException('Unsupported file type: '.$mime);$name=bin2hex(random_bytes(16)).'.'.$allowed[$mime];if(!move_uploaded_file($tmp,UPLOADS.'/'.$name))throw new RuntimeException('Could not save upload.');$stmt=$db->prepare('INSERT INTO media(type,filename,original_name,title,caption,category_id,memory_date,favorite,featured) VALUES(?,?,?,?,?,?,?,?,?)');$stmt->execute([$kind,$name,basename($files['name'][$i]),$_POST['title']??'',$_POST['caption']??'',($_POST['category_id']??'')?:null,($_POST['memory_date']??'')?:null,!empty($_POST['favorite']),!empty($_POST['featured'])]);$out[]=$db->lastInsertId();}json_out(['ok'=>true,'ids'=>$out]);
   }
   if($action==='delete_media'){$id=(int)$_POST['id'];$q=$db->prepare('SELECT filename FROM media WHERE id=?');$q->execute([$id]);$f=$q->fetchColumn();if($f&&is_file(UPLOADS.'/'.$f))unlink(UPLOADS.'/'.$f);$db->prepare('DELETE FROM media WHERE id=?')->execute([$id]);json_out(['ok'=>true]);}
   if($action==='save_settings'){foreach($_POST['settings']??[] as $k=>$v){if(!preg_match('/^[a-z_]+$/',$k))continue;$db->prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')->execute([$k,trim((string)$v)]);}json_out(['ok'=>true]);}
   if($action==='save_item'){$table=$_POST['table']??'';$allowed=['chapters'=>['title','period','body','position'],'envelopes'=>['title','body','style','position'],'future_ideas'=>['title','note','position']];if(!isset($allowed[$table]))throw new RuntimeException('Invalid content type.');$fields=$allowed[$table];$vals=[];foreach($fields as $f)$vals[]=$_POST[$f]??'';$id=(int)($_POST['id']??0);if($id){$set=implode(',',array_map(fn($x)=>"$x=?",$fields));$db->prepare("UPDATE $table SET $set WHERE id=?")->execute([...$vals,$id]);}else{$db->prepare("INSERT INTO $table(".implode(',',$fields).") VALUES(".implode(',',array_fill(0,count($fields),'?')).")")->execute($vals);}json_out(['ok'=>true]);}
   if($action==='delete_item'){$table=$_POST['table']??'';if(!in_array($table,['chapters','envelopes','future_ideas','questions'],true))throw new RuntimeException('Invalid content type.');$db->prepare("DELETE FROM $table WHERE id=?")->execute([(int)$_POST['id']]);json_out(['ok'=>true]);}
   if($action==='save_question'){$opts=array_values(array_filter($_POST['options']??[],fn($x)=>trim($x)!==''));if(count($opts)<2)throw new RuntimeException('Add at least two answer choices.');$id=(int)($_POST['id']??0);$v=[$_POST['prompt']??'',json_encode($opts),(int)($_POST['correct_index']??0),(int)($_POST['position']??0)];if($id)$db->prepare('UPDATE questions SET prompt=?,options_json=?,correct_index=?,position=? WHERE id=?')->execute([...$v,$id]);else $db->prepare('INSERT INTO questions(prompt,options_json,correct_index,position) VALUES(?,?,?,?)')->execute($v);json_out(['ok'=>true]);}
   if($action==='save_category'){$id=(int)($_POST['id']??0);$name=trim($_POST['name']??'');if($name==='')throw new RuntimeException('A category needs a name.');$slug=strtolower(trim(preg_replace('/[^a-z0-9]+/','-',iconv('UTF-8','ASCII//TRANSLIT',$name)),'-'));if($id)$db->prepare('UPDATE categories SET name=?,slug=? WHERE id=?')->execute([$name,$slug,$id]);else$db->prepare('INSERT INTO categories(name,slug,position) VALUES(?,?,99)')->execute([$name,$slug]);json_out(['ok'=>true]);}
   if($action==='delete_category'){$id=(int)$_POST['id'];$db->prepare('DELETE FROM categories WHERE id=?')->execute([$id]);json_out(['ok'=>true]);}
   throw new RuntimeException('Unknown action.');
  }catch(Throwable $e){json_out(['ok'=>false,'error'=>$e->getMessage()],400);}
}
if($page==='login'){?><!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="assets/style.css"><title>Admin login</title></head><body class="login-page"><main class="login-card"><p class="eyebrow">A LITTLE UNIVERSE CALLED BATUK</p><h1>Welcome back, Akash.</h1><form method="post"><label>Password<input type="password" name="password" autofocus required></label><?php if(!empty($loginError))echo'<p class="error">'.esc($loginError).'</p>';?><button>Enter dashboard</button></form><small>Set <code>ADMIN_PASSWORD</code> before sharing this site.</small></main></body></html><?php exit;}
if($page==='admin'){admin_required();require ROOT.'/views/admin.php';exit;}
require ROOT.'/views/public.php';
