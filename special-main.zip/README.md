# A Little Universe Called Batuk

A responsive, persistent birthday experience for Shivani (Batuk), built for WAMP/PHP 8 with SQLite. It ships empty of personal media and is ready for Akash to personalize through `/per/?page=admin`.

## Run locally

1. Ensure PHP has `pdo_sqlite`, `sqlite3`, `fileinfo`, and uploads enabled.
2. Point Apache/WAMP at this directory (under the supplied setup, visit `http://localhost/per/`).
3. Configure a strong server environment variable before using the dashboard. In Apache VirtualHost configuration, for example:

   ```apache
   SetEnv ADMIN_PASSWORD "use-a-long-unique-password-here"
   ```

   Restart Apache, then visit `http://localhost/per/?page=admin`.
4. Upload real images and videos, select a category, edit captions, and use **Preview site** before sharing.

The first request creates `data/universe.sqlite`, seeded only with editable story structure and draft copy. The database and personal uploads are excluded from Git.

## Features

- Cinematic intro with skip control and reduced-motion support.
- Responsive public experience: chapters, filterable/searchable gallery, keyboard/swipe lightbox, game-zone video playback, Garba scene, interactive notes, quiz, constellation, letter, and finale.
- Protected dashboard with CSRF-protected writes, server-side file MIME/size validation, upload progress feedback, persistent SQLite metadata, and delete confirmations.
- Actual content-driven counts; no fabricated memory statistics.

## Security and privacy

- The dashboard accepts no writes without a valid authenticated PHP session and CSRF token.
- Do not set a weak `ADMIN_PASSWORD`; never commit it. The dashboard deliberately rejects all login attempts if it has not been configured.
- `data/` is denied by Apache via its own `.htaccess`; keep Apache’s `AllowOverride` enabled or move it outside the web root in production.
- Uploaded media is intentionally web-readable because the public birthday page displays it. An unlisted link is not private: anyone with the link can forward it.
- For stronger privacy, put the app behind authenticated access and move uploads to private object storage (S3/Supabase Storage) served through short-lived signed URLs. This local WAMP build is ideal for authoring and small private hosting, not large video delivery.

## Backup and deployment

Back up both `data/universe.sqlite` and the entire `uploads/` directory at the same time. The SQLite file holds captions, settings, categories, chapters, notes, quiz questions, and media file references; media binaries live in `uploads/`.

For a public deployment, use a PHP-capable HTTPS host with persistent disk, set `ADMIN_PASSWORD` in host secrets, preserve write access only to `data/`, `data/sessions/`, and `uploads/`, and set PHP upload limits to match your desired maximum video size. For higher reliability, migrate media to object storage before sharing large videos.

## Verification completed

`php -l` has been run successfully on `index.php`, `views/public.php`, and `views/admin.php`. Browser interaction still needs a final visual check in your local WAMP browser after configuring the admin password.
